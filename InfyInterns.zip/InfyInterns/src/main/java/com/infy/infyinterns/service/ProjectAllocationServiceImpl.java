package com.infy.infyinterns.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.infyinterns.dto.MentorDTO;
import com.infy.infyinterns.dto.ProjectDTO;
import com.infy.infyinterns.entity.Mentor;
import com.infy.infyinterns.entity.Project;
import com.infy.infyinterns.exception.InfyInternException;
import com.infy.infyinterns.repository.MentorRepository;
import com.infy.infyinterns.repository.ProjectRepository;


@Service(value = "projectService")
@Transactional
public class ProjectAllocationServiceImpl implements ProjectAllocationService {
	
	@Autowired
	private MentorRepository mentorRepository;
	
	@Autowired
	private ProjectRepository projectRepository;
	
	@Override
	public Integer allocateProject(ProjectDTO project) throws InfyInternException {
		Optional<Mentor> optional = mentorRepository.findById(project.getMentorDTO().getMentorId());
		Mentor mentor = optional.orElseThrow(() -> new InfyInternException("Service.MENTOR_NOT_FOUND"));
		if(mentor.getNumberOfProjectsMentored() >= 3) throw new InfyInternException("Service.CANNOT_ALLOCATE_PROJECT");
		
		Project projectEntity = new Project();
		projectEntity.setProjectName(project.getProjectName());
		projectEntity.setIdeaOwner(project.getIdeaOwner());
		projectEntity.setReleaseDate(project.getReleaseDate());
		projectEntity.setMentor(mentor);
		
		Integer returnedProjectId = projectRepository.save(projectEntity).getProjectId();
		
		Integer currentNumberOfProjectsMentored = mentor.getNumberOfProjectsMentored();
		mentor.setNumberOfProjectsMentored(currentNumberOfProjectsMentored+1);
		
		return returnedProjectId;
	}

	
	@Override
	public List<MentorDTO> getMentors(Integer numberOfProjectsMentored) throws InfyInternException {
		List<Mentor> mentors = mentorRepository.findByNumberOfProjectsMentored(numberOfProjectsMentored);
		if(mentors.isEmpty()) throw new InfyInternException("Service.MENTOR_NOT_FOUND");
		List<MentorDTO> mentorDTOs = new ArrayList<MentorDTO>();
		mentors.forEach((Mentor mentor) -> {
			MentorDTO mentorDTO = new MentorDTO();
			mentorDTO.setMentorId(mentor.getMentorId());
			mentorDTO.setMentorName(mentor.getMentorName());
			mentorDTO.setNumberOfProjectsMentored(mentor.getNumberOfProjectsMentored());
			mentorDTOs.add(mentorDTO);
		});
		return mentorDTOs;
	}


	@Override
	public void updateProjectMentor(Integer projectId, Integer mentorId) throws InfyInternException {
		Optional<Mentor> optionalMentor = mentorRepository.findById(mentorId);
		Mentor mentor = optionalMentor.orElseThrow(() -> new InfyInternException("Service.MENTOR_NOT_FOUND"));
		if(mentor.getNumberOfProjectsMentored() >= 3) throw new InfyInternException("Service.CANNOT_ALLOCATE_PROJECT");
		
		Optional<Project> optionalProject = projectRepository.findById(projectId);
		Project project = optionalProject.orElseThrow(() -> new InfyInternException("Service.PROJECT_NOT_FOUND"));
		project.setMentor(mentor);
		
		Integer currentNumberOfProjectsMentored = mentor.getNumberOfProjectsMentored();
		mentor.setNumberOfProjectsMentored(currentNumberOfProjectsMentored+1);
	}

	@Override
	public void deleteProject(Integer projectId) throws InfyInternException {
		Optional<Project> optional = projectRepository.findById(projectId);
		Project project = optional.orElseThrow(() -> new InfyInternException("Service.PROJECT_NOT_FOUND"));
		if(project.getMentor() != null) {
			Mentor mentor = mentorRepository.findById(project.getMentor().getMentorId()).get();
			project.setMentor(null);
			Integer currentNumberOfProjectsMentored = mentor.getNumberOfProjectsMentored();
			mentor.setNumberOfProjectsMentored(currentNumberOfProjectsMentored-1);
		}
		projectRepository.delete(project);
	}
}