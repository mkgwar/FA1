package com.infy.infyinterns.exception;

public class InfyInternException extends Exception {

	private static final long serialVersionUID = 1L;

	public InfyInternException(String message) {
		super(message);	
	}
}
